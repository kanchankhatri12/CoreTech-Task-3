<?php include "db_connect.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <title>View Students</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Registered Students</h2>
    <?php
    if (isset($_GET['delete'])) {
        $id = intval($_GET['delete']);
        $conn->query("DELETE FROM students WHERE id=$id");
        echo "<p style='color:green;'>Student deleted successfully!</p>";
    }

    $result = $conn->query("SELECT * FROM students");
    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Roll No</th>
                    <th>Department</th>
                    <th>Action</th>
                </tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['roll_number']}</td>
                    <td>{$row['department']}</td>
                    <td><a href='?delete={$row['id']}'><button class='delete-btn'>Delete</button></a></td>
                </tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No students registered yet.</p>";
    }
    ?>
    <p style="text-align:center;"><a href="index.php" style="color:#f5d142;">Go Back to Registration</a></p>
</div>
</body>
</html>
