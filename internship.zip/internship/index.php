<?php include "db_connect.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Student Registration</h2>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $roll_number = trim($_POST['roll_number']);
        $department = trim($_POST['department']);

        if (empty($name) || empty($email) || empty($roll_number) || empty($department)) {
            echo "<p style='color:red;'>All fields are required!</p>";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<p style='color:red;'>Invalid email format!</p>";
        } else {
            $stmt = $conn->prepare("INSERT INTO students (name, email, roll_number, department) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $email, $roll_number, $department);
            if ($stmt->execute()) {
                echo "<p style='color:green;'>Student registered successfully!</p>";
            } else {
                echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
            }
            $stmt->close();
        }
    }
    ?>
    <form method="post" action="">
        <input type="text" name="name" placeholder="Full Name">
        <input type="email" name="email" placeholder="Email Address">
        <input type="text" name="roll_number" placeholder="Roll Number">
        <select name="department">
            <option value="">Select Department</option>
            <option value="Computer Science">Computer Science</option>
            <option value="Electronics">Electronics</option>
            <option value="Mechanical">Mechanical</option>
            <option value="Civil">Civil</option>
        </select>
        <input type="submit" value="Register">
    </form>
    <p style="text-align:center;"><a href="view_students.php" style="color:#f5d142;">View Registered Students</a></p>
</div>
</body>
</html>
